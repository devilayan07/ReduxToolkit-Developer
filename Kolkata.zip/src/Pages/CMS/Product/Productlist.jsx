import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { fetchProduct } from '../../ReduxToolkit/ProductSlice'
import {  Typography, Card, CardMedia, CardContent, CardActions, Button, CardActionArea, Grid } from '@mui/material'
import { myproduct } from '../../../Component/Helper/Helper'
import { Link } from 'react-router-dom'

function Productlist() {
    const Products=useSelector(state=>state.Product)
    console.log(Products)
    const dispatch=useDispatch()

    useEffect(()=>{
        dispatch(fetchProduct())
    },[dispatch])
  return (
    <section >
    <Typography variant='h5'textAlign={"center"} sx={{marginTop:"80px"}}>Avilabel Models</Typography>
    <Grid container  >
      {
        Array.isArray(Products.product.data) && Products.product.data.map((item, index) =>
          <Grid item xs={12} md={4} sx={{ marginTop: "30px", paddingLeft: "10px"}}>
            <Card sx={{ marginTop: "20px", maxWidth: 350, height: "400px" }}>
              <CardActionArea>
                <CardMedia
                  component="img"
                  height="200px"
                  image={myproduct(item.image)} />
                <CardContent>
                  <Typography variant='h5' component="div" textAlign="center">{item.title}</Typography>
                  <Typography variant='h6' component="div" >{item.description}</Typography>

                </CardContent>
              </CardActionArea>
              <CardActions sx={{ justifyContent: "center" }}>
                <Link to={`/product/${item._id}`}><Button variant='outlined'>Edit</Button></Link>

              </CardActions>

            </Card>
          </Grid>
        )
      }

    </Grid>
    </section>

  )
}

export default Productlist
