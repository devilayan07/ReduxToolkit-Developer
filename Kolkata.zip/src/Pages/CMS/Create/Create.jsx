import React from 'react'
import { Container,Box,TextField,Typography,Button } from '@mui/material';
import { useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import { fetchCreate } from '../../ReduxToolkit/CreateSlice';

function Create() {
    const{register,handleSubmit,formState:{errors}}=useForm()
    const dispatch=useDispatch()

    const onSubmit=(data)=>{
        const formdata=new FormData()
        formdata.append("title",data.title)
        formdata.append("description",data.description)
        formdata.append("image",data.image[0])
         dispatch(fetchCreate(formdata))


    }


  return (
    <Container component="main" maxWidth="xs">

    <Box
      sx={{ marginTop: "80px" }}>
      <Typography textAlign={"center"} variant='h5'>Create Data</Typography>

      <Box component="form"  sx={{ margin: "20px", padding: "10px", alignItems: "center" }}  >
        <TextField
        {...register("title",{required:true})}
          margin='normal'
          fullWidth

          id='title'
          label="Enter The Title"
          name='title'
          autoComplete='title'
          error={errors.title}
          helperText={errors.title && "Title is required"}
          autoFocus
        />


        <TextField
        {...register("description",{required:true})}
          margin='normal'
          fullWidth

          id='description'
          label="Enter The Description"
          name='description'
          autoComplete='description'
          error={errors.description}
          helperText={errors.description && "Description is required"}
          autoFocus
        />

<TextField
                {...register("image", { required: true, maxLength: 20 })}

                fullWidth
                margin="normal"
                variant="outlined"
                type="file"
                error={!!errors.image}
                helperText={errors.image && "Image is required"}
              />


       
        <Button
                variant="contained"
                color="secondary"
                fullWidth
                size="large"
                type="submit"
                onClick={handleSubmit(onSubmit)}
              >
                Submit
              </Button>
</Box>
</Box>
</Container>

  )
}

export default Create
