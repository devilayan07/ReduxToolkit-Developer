import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useParams } from 'react-router-dom'
import { fetchDetails, fetchEdit } from '../../ReduxToolkit/ProductSlice'
import { useForm } from 'react-hook-form'
import { Container,Box,TextField,Typography,Button } from '@mui/material';

function Edit() {
    const{id}=useParams()
    console.log(id)
    const {detail}=useSelector(state=>state.Product)
    console.log(detail)
    const dispatch=useDispatch()
const{register,handleSubmit,formState:{errors}}=useForm()
    useEffect(()=>{
        dispatch(fetchDetails(id))
    },[dispatch,id])

    const onSubmit=(detail)=>{
        const formdata=new FormData()
        formdata.append("title",detail.data.title)
        formdata.append("description",detail.data.description)
        formdata.append("image",detail.data.image[0])
        formdata.append("id",detail.data.id)

        dispatch(fetchEdit(formdata))


    }
  return (
    <Container component="main" maxWidth="xs">

    <Box
      sx={{ marginTop: "80px" }}>
      <Typography textAlign={"center"} variant='h5'>Edit Data</Typography>

      <Box component="form"  sx={{ margin: "20px", padding: "10px", alignItems: "center" }}  >
        <TextField
        {...register("title",{required:true})}
          margin='normal'
          fullWidth

          id='title'
          label="Enter The Title"
          name='title'
          autoComplete='title'
          error={errors.title}
          helperText={errors.title && "Title is required"}
          autoFocus
        />


        <TextField
        {...register("description",{required:true})}
          margin='normal'
          fullWidth

          id='description'
          label="Enter The Description"
          name='description'
          autoComplete='description'
          error={errors.description}
          helperText={errors.description && "Description is required"}
          autoFocus
        />

<TextField
                {...register("image", { required: true, maxLength: 20 })}

                fullWidth
                margin="normal"
                variant="outlined"
                type="file"
                error={!!errors.image}
                helperText={errors.image && "Image is required"}
              />


       
        <Button
                variant="contained"
                color="secondary"
                fullWidth
                size="large"
                type="submit"
                onClick={handleSubmit(onSubmit)}
              >
                Submit
              </Button>
</Box>
</Box>
</Container>

  

  )
}

export default Edit
