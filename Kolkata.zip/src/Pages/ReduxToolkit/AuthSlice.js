import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axiosInstance from "../../Component/Helper/Helper";
import { toast } from "react-toastify";

export const register=createAsyncThunk("/user/signup",async(formdata)=>{
    const response=await axiosInstance.post("/user/signup",formdata)
    return response.data
    
})

export const login=createAsyncThunk("/user/signin",async(formdata)=>{
    const response=await axiosInstance.post("/user/signin",formdata)
    return response.data
})
const AuthSlice=createSlice({
    name:"registration",
    initialState:{
        status:"idle"
    },

    extraReducers:(builder)=>{
       builder.addCase(register.pending,(state)=>{
        state.status="loading"
       })
       builder.addCase(register.fulfilled,(state,action)=>{
        state.status="idle"
        if(action.payload?.status===200){
            toast(action.payload?.message)
        }
       })
       builder.addCase(register.rejected,(state,action)=>{
        state.status="idle"

       })
       builder.addCase(login.pending,(state)=>{
        state.status="loading"
       })
       builder.addCase(login.fulfilled,(state,action)=>{
        state.status="idle"
        if(action.payload?.status===200){
            toast(action.payload?.message)
            localStorage.setItem("token",action.payload?.token)
        }
       })
       builder.addCase(login.rejected,(state)=>{
        state.status="idle"
       })
    }

})

export default AuthSlice.reducer;