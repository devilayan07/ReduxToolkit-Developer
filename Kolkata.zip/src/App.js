import './App.css';
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom';
import Registration from './Pages/AUTH/Registration/Registration';
import Login from './Pages/AUTH/Login/Login';
import Home from './Pages/CMS/Home/Home';
import Create from './Pages/CMS/Create/Create';
import Productlist from './Pages/CMS/Product/Productlist';
import Edit from './Pages/CMS/Edit/Edit';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/registration" element={<Registration/>}/>
          <Route path='/login' element={<Login/>}/>
          <Route path='/' element={<Home/>}/>
          <Route path='/create' element={<Create/>}/>
          <Route path="/product" element={<Productlist/>}/>
          <Route path="/product/:id" element={<Edit/>}/>
        </Routes>
      </Router>

    </div>
  );
}

export default App;
